# ARBRE COUVRANT MINIMAL

####*Auteurs* : ####
* Leo PERARD
* Salla DIAGNE

# Fonctionnement des programmes
* Se placer à la racine du projet (dossier tp2_perard-diagne/)
* tester une archive en exécutant java -jar nom_archive.jar et voir comment le programme s'utilise (en lançant l'exemple par exemple)
