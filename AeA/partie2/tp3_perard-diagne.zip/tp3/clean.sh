rm *_p*
rm results_*
rm *.ps
rm *.dot
