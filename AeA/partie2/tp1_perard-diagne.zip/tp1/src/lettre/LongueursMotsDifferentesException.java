package lettre;

public class LongueursMotsDifferentesException extends Exception {

	private static final long serialVersionUID = -7271165460448738421L;

}